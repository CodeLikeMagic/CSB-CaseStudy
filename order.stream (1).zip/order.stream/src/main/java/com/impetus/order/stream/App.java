package com.impetus.order.stream;

import java.nio.ByteBuffer;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.model.PutRecordsRequest;
import com.amazonaws.services.kinesis.model.PutRecordsRequestEntry;
import com.amazonaws.services.kinesis.model.PutRecordsResult;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.impetus.order.stream.App;
import com.impetus.order.stream.aws.AwsKinesisClient;
import com.impetus.order.stream.model.Order;

/**
 * Hello world!
 *
 */
public class App {
	static List<String> itemList = new ArrayList<String>();
	static List<String> shipMode = new ArrayList<String>();
	static List<String> cityList = new ArrayList<String>();
	static List<String> postalCodeList = new ArrayList<String>();
	static List<String> segmentList = new ArrayList<String>();
	
	Random random = new Random();

	public static void main(String[] args) throws InterruptedException {
		App app = new App();
		app.populateShipMode();
		app.populateItemList();
		app.populateCityList();
		app.populatePostalList();
		app.populateSegmentList();
		
		/*
		List<Order> sampleData;
		sampleData = getOrderList();
		*/
		
		List<PutRecordsRequestEntry> putData = getRecordsRequestList();
		
		// 1. get client
		/*AmazonKinesis kinesisClient = AwsKinesisClient.getKinesisClient();
		while (true) {
			app.sendData(kinesisClient);
			Thread.sleep(20000);
		}*/

	}

	private void sendData(AmazonKinesis kinesisClient) {
		// 2. PutRecordRequest
		PutRecordsRequest recordsRequest = new PutRecordsRequest();
		recordsRequest.setStreamName("order-stream");
		recordsRequest.setRecords(getRecordsRequestList());

		// 3. putRecord or putRecords - 500 records with single API call
		PutRecordsResult results = kinesisClient.putRecords(recordsRequest);
		if (results.getFailedRecordCount() > 0) {
			System.out.println("Error occurred for records " + results.getFailedRecordCount());
		} else {
			System.out.println("Data sent successfully...");
		}

	}

	private static List<PutRecordsRequestEntry> getRecordsRequestList() {
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		List<PutRecordsRequestEntry> putRecordsRequestEntries = new ArrayList<PutRecordsRequestEntry>();
		for (Order order : getOrderList()) {
			PutRecordsRequestEntry requestEntry = new PutRecordsRequestEntry();
			requestEntry.setData(ByteBuffer.wrap(gson.toJson(order).getBytes()));
			requestEntry.setPartitionKey(UUID.randomUUID().toString());
//			System.out.println(requestEntry);		/////
			putRecordsRequestEntries.add(requestEntry);
		}
		return putRecordsRequestEntries;
	}

	
	private static List<Order> getOrderList() {
		List<Order> orders = new ArrayList<Order>();
		Random random = new Random();
		for (int i = 1; i <= 500; i++) {
			Order order = new Order();
			
			order.setOrderId(i);	///id -- loop [1-500]
			
			order.setOrderDate(java.time.LocalDate.now());		///order date
			String todaysDate = new String(LocalDate.now().toString()); 
			order.setShipDate(LocalDate.parse(todaysDate).plusDays(random.nextInt(6) + 5));	///generates 5- 10 day after placing order		
			
			order.setShipMode(shipMode.get(random.nextInt(shipMode.size())));
			order.setCustomerId(random.nextInt(500) + 100);
			
			order.setSegment(segmentList.get(random.nextInt(segmentList.size())));
			order.setCityNames(cityList.get(random.nextInt(cityList.size())));
			order.setCountryNames("INDIA");
			order.setPostalCode(postalCodeList.get(random.nextInt(postalCodeList.size())));
			
			order.setItem(itemList.get(random.nextInt(itemList.size())));
			order.setQuantity(random.nextInt(10) + 1);
			order.setCost(random.nextInt(900) + 100);
			order.setTotal(order.getCost() * order.getQuantity());
			
			order.setProfit(order.getTotal() * (random.nextInt(15 + 5) - 10)/100);
			
			System.out.println(order);
			orders.add(order);
			/*order.setOrderId(Math.abs(random.nextInt()));
			order.setItem(itemList.get(random.nextInt(itemList.size())));
			order.setQuantity(random.nextInt(20));
			orders.add(order);*/
		}
		return orders;
	}

	private void populateShipMode() {
		shipMode.add("STANDARD");
		shipMode.add("FIRST CLASS");
		shipMode.add("SECOND CLASS");
	}
	
	private void populateCityList() {
		cityList.add("INDORE");
		cityList.add("PUNE");
		cityList.add("HYDERABAD");
		cityList.add("BANGLORE");
		cityList.add("NOIDA");
		cityList.add("CHENNAI");
		cityList.add("JAIPUR");
		cityList.add("CHANDIGARH");
		cityList.add("KERALA");
		cityList.add("SIKKIM");
		cityList.add("DELHI");
		cityList.add("GUJARAT");
		cityList.add("KANPUR");
		cityList.add("AGRA");
		cityList.add("GUWAHATI");
	}
	
	private void populatePostalList() {
		postalCodeList.add("400004");
		postalCodeList.add("110020");
		postalCodeList.add("560064");
		postalCodeList.add("110097");
		postalCodeList.add("110001");	
		postalCodeList.add("400008");
		postalCodeList.add("400005");
		postalCodeList.add("201301");
		postalCodeList.add("563130");
		postalCodeList.add("584101");		
		postalCodeList.add("414001");
		postalCodeList.add("307501");
		postalCodeList.add("194404");
		postalCodeList.add("307501");
		postalCodeList.add("194201");
		
	}
	
	private void populateItemList() {
		itemList.add("REDBULL");
		itemList.add("NOODLES");
		itemList.add("DAIRYMILK");
		itemList.add("DORITOS");
		itemList.add("PASTA");
		
		itemList.add("MILK");
		itemList.add("CHEERIOS");
		itemList.add("OATS");
		itemList.add("BREAD");
		itemList.add("CHESSE");
		
		itemList.add("FOOD OIL");
		itemList.add("KETCHUP");
		itemList.add("COOKIES");
		itemList.add("MAYONNAISE");
		itemList.add("RICE");
		
		itemList.add("WHEAT");
		itemList.add("PULSES");
		itemList.add("RAJMA");
		itemList.add("BUTTER");
		itemList.add("NUTELLA");
/////////////////////		
		itemList.add("JACKETS");
		itemList.add("SKIRTS");
		itemList.add("COATS");
		itemList.add("SOCKS");
		itemList.add("CO-ORDS");
		
		itemList.add("TOPS");
		itemList.add("JEANS");
		itemList.add("TROUSERS");
		itemList.add("T-SHIRT");
		itemList.add("SHIRT");
		
		itemList.add("SWIM-WEAR");
		itemList.add("ACTIVE-WEAR");
		itemList.add("SUITS");
		itemList.add("SHERWANIS");
		itemList.add("LEHENGA CHOLIS");
		
		itemList.add("SHRUGS");
		itemList.add("SWEATSHIRTS");
		itemList.add("JUMPSUITS");
		itemList.add("BLAZERS");
		itemList.add("KURTA SET");
/////////////////////
		itemList.add("PLANTERS");
		itemList.add("MIRRORS");
		itemList.add("CARPETS");
		itemList.add("PILLOWS");
		itemList.add("BED");
		
		itemList.add("TABLE LAMPS");
		itemList.add("DOOR MATS");
		itemList.add("SOFA COVERS");
		itemList.add("CLOCKS");
		itemList.add("DINNERWARE");
		
		itemList.add("BAKERWARE");
		itemList.add("COOKWARE");
		itemList.add("DRINKWARE");
		itemList.add("FLOOR MATS");
		itemList.add("BATHROOM ACCESSORIES");
		
		itemList.add("BLANKETS");
		itemList.add("QUILTS");
		itemList.add("AROMAS AND CANDLES");
		itemList.add("WALL DECOR");
		itemList.add("VASES");
/////////////////////
		itemList.add("BOOTS");
		itemList.add("CASUAL SHOES");
		itemList.add("FLATS");
		itemList.add("FLIP FLOPS");
		itemList.add("FORMAL SHOES");
		
		itemList.add("HEELS");
		itemList.add("SPORTS SHOES");
		itemList.add("SANDALS");
		itemList.add("SPORTS SANDALS");
		itemList.add("SNEAKERS");
		
		itemList.add("CHELSEA BOOTS");
		itemList.add("RAIN BOOTS");
		itemList.add("GLADIATORS");
		itemList.add("PEEP TOES");
		itemList.add("LOAFERS");
		
		itemList.add("SKATE SHOES");
		itemList.add("TREKKING SHOES");
		itemList.add("BALLERINAS");
		itemList.add("MULES");
		itemList.add("CROCS");
	}
	
	private void populateSegmentList() {
		segmentList.add("FOOD");
		segmentList.add("APPARELS");
		segmentList.add("HOME&LIVING");
		segmentList.add("FOOTWEAR");
	}
}
