package com.impetus.order.stream.model;

import java.time.LocalDate;
import java.util.Date;

/*
 * 
Order ID: String (Alphanumerical)
Order Date: Date
Ship Date: Date
Ship Mode: Options (Standard Class, First Class, Second Class)
Customer ID: String (Alphanumerical)
Segment: Options (Technology, Office, NGO)
City: City Names
Country: Country Name
Postal Code: Pincode
Item Type: Options
Item ID: Alphanumerical
Quantity: Integer
Cost: Integer
Total: Integer
Profit: Integer
 * 
 */
public class Order {
	int orderId;
	public String orderDate;
	public String shipDate;
	String shipMode;
	int customerId;
	String segment;
	String cityNames;
	String countryNames;
	String postalCode;
    String item;
    int quantity;
    int cost;
    int total;
    int profit;

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

	public String getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate.toString();
	}

	public String getShipDate() {
		return shipDate;
	}

	public void setShipDate(LocalDate shipDate) {
		this.shipDate = shipDate.toString();
	}

	public String getShipMode() {
		return shipMode;
	}

	public void setShipMode(String shipMode) {
		this.shipMode = shipMode;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public String getCityNames() {
		return cityNames;
	}

	public void setCityNames(String cityNames) {
		this.cityNames = cityNames;
	}

	public String getCountryNames() {
		return countryNames;
	}

	public void setCountryNames(String countryNames) {
		this.countryNames = countryNames;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public int getCost() {
		return cost;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getProfit() {
		return profit;
	}

	public void setProfit(int profit) {
		this.profit = profit;
	}
    
    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    @Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDate=" + orderDate + ", shipDate=" + shipDate + ", shipMode="
				+ shipMode + ", customerId=" + customerId + ", segment=" + segment + ", cityNames=" + cityNames
				+ ", countryNames=" + countryNames + ", postalCode=" + postalCode + ", item=" + item + ", quantity="
				+ quantity + ", cost=" + cost + ", total=" + total + ", profit=" + profit + "]";
	}
}
